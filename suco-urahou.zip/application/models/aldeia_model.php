<?php 
class aldeia_model extends CI_model{
	public function fosai_dadus()
	{
		return $this->db->get('t_aldeia');
		
	}
	function get()
    {
        //SELECT * FROM tabel_mahasiswa
        return $this->db->get('t_aldeia');
       
    }
	public function countAllaldeia()
	{
		return $this->db->get('t_aldeia')->num_rows();
	}
	public function input_dadus($data)
	{
		$this->db->insert('t_aldeia',$data);
	}
	public function edit_data($where,$table)
	{
		return $this->db->get_where($table,$where);
	}
	public function update_data($where,$data,$table)
	{
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	public function hamos_data($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}
}