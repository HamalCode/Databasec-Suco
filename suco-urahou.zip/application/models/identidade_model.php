<?php 

class identidade_model extends CI_Model{

	public $table ='t_identidade';
	public $id    ='id_identidade';
	

	public function fosai_dadus($table)
	{
		return $this->db->get($table);
	}
	
	public function edit_data($where,$table)
	{
		return $this->db->get_where($table,$where);
	}
	public function update_data($where,$data,$table)
	{
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	
}