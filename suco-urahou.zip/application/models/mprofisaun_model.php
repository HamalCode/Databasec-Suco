<?php 
class mprofisaun_model extends CI_model{
	public function fosai_dadus($table)
	{
		return $this->db->get($table);
		
	}

	public function countAllaldeia()
	{
		return $this->db->get('t_mprofisaun')->num_rows();
	}
	public function input_dadus($data)
	{
		$this->db->insert('t_mprofisaun',$data);
	}
	public function edit_data($where,$table)
	{
		return $this->db->get_where($table,$where);
	}
	public function update_data($where,$data,$table)
	{
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	public function hamos_data($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}
}