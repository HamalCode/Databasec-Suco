<?php 
class prosesu_model extends CI_Model{
	public function fosai_dadus($limit, $start)
	{

		return $this->db->get('t_populasaun', $limit, $start);
		
	}

    function get()
    {
        //SELECT * FROM tabel_mahasiswa
        return $this->db->get('t_populasaun');
       
    }
	public function countAllpopulasaun()
	{
		return $this->db->get('t_populasaun')->num_rows();
	}
	public function foti_id_populasaun($id)
	{
		$resultadu = $this->db->where('id',$id)->get('t_populasaun');
		if($resultadu->num_rows() > 0){
			return $resultadu->result();
		}else{
			return false;
		}
   }
   public function insert_data($data,$table)
   {
   	$this->db->insert($table,$data);
   }
   public function edit_data($where,$table)
	{
		return $this->db->get_where($table,$where);
	}
	public function update_data($where,$data,$table)
	{
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	public function hamos_data($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}
	

}