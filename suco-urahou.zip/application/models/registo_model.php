<?php
defined('BASEPATH') or exit('No direct script access allowed');
class registo_model extends CI_Model
{
    function get()
    {
        //SELECT * FROM tabel_mahasiswa
        return $this->db->get('t_registo');
       
    }
   
    
    function insert($data)
    {
        //insert data ke dalam tabel
        $this->db->insert('t_registo', $data);
    }
   
    function get_by_nrep($nrep)
    {
        //SELECT * FROM tabel_mahasiswa WHERE nim=$nim
        $this->db->where('nrep', $nrep);
        $this->db->from('t_registo');
        return $this->db->get();
    }

    function update($data, $where)
    {
        $this->db->where($where);
        $this->db->update('t_registo', $data);
    }

    function delete($nrep)
    {
        //delete data berdasarkan nim
        $this->db->where('nrep', $nrep);
        $this->db->delete('t_registo');
    }

}