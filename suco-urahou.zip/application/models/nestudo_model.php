<?php 
class nestudo_model extends CI_model{
	public function fosai_dadus()
	{
		return $this->db->get('t_nivel_estudu');
		
	}

	public function countAllaldeia()
	{
		return $this->db->get('t_nivel_estudu')->num_rows();
	}
	public function input_dadus($data)
	{
		$this->db->insert('t_nivel_estudu',$data);
	}
	public function edit_data($where,$table)
	{
		return $this->db->get_where($table,$where);
	}
	public function update_data($where,$data,$table)
	{
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	public function hamos_data($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}
}