<center><strong> RELATORIO DADUS POPULASAUN ALDEIA URA-HOU<br>
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table border="1" width="100%" style="text-align:center;">
	
			<tr>
				<th>No</th>
                    <th> Id Aldeia</th>
                    <th>Naran Aldeia</th>
                  
			
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_aldeia as $ald) : ?>
			<tr>
                    <td><?php echo $no++ ?></td>
					<td><?php echo $ald->code_aldeia?></td>
                    <td><?php echo $ald->nrn_aldeia?></td>
					
			</tr>
		<?php endforeach; ?>
		
		
	</table>
	<br>
	
  <script type="text/javascript">
     window.print();
   </script>
</body></html>