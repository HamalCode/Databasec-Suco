<center><strong> RELATORIO DADUS POPULASAUN SUKU URA-HOU<br>
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table border="1" width="100%" style="text-align:center;">
	
			<tr>
				<th>No</th>
                    <th> Id Populasaun</th>
                    <th>Naran Completo</th>
                    <th>Fatin Moris</th>
                    <th>Data Moris</th>
                    <th>Hela Sexo</th>
                    <th>Id Religiaun</th>
                    <th> obs</th>
			
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_populasaun as $pop) : ?>
			<tr>
                    <td><?php echo $no++ ?></td>
					<td><?php echo $pop->id_populasaun?></td>
                    <td><?php echo $pop->nrn_kompletu?></td>
                    <td><?php echo $pop->f_moris?></td>
                    <td><?php echo $pop->d_moris?></td>
                    <td><?php echo $pop->sexo?></td>
                    <td><?php echo $pop->code_reli?></td>
                    <td><?php echo $pop->obs?></td>
					
			</tr>
		<?php endforeach; ?>
		
		
	</table>
	<br>
	
  <script type="text/javascript">
     window.print();
   </script>
</body></html>