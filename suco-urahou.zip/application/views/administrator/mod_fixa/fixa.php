<!DOCTYPE html>
<html lang="en">

<body class="hold-transition sidebar-mini">
<div class="wrapper">
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dadus Fixa</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header bg-info">
                <h3 class="card-title">Tabela Fixa Familia</h3>
               
              </div>
              <?php echo $this->session->flashdata('mensagem') ?>
	            <?php echo anchor('administrator/fixa/input',' <button class="btn btn-sm btn-warning mb-1 mt-4 ml-3"><i class="fas fa-plus fa-sm"></i> Amenta Data</button>') ?>  
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th> Id Fixa</th>
                    <th>Id Populasaun</th>
                    <th>Data Moris</th>
                    <th colspan="2">Asaun</th>
                  </tr>
                  </thead>
                  
                  <tr>
                  <?php 
	           	$no =1;
               if ($jumlah_data > 0) {
	          	foreach ($t_fixa_familia as $fix):
	            	 ?>
                 <td width="20px"><?php echo $no++ ?></td>
                    <td><?php echo $fix->id_fixa?></td>
                    <td><?php echo $fix->id_populasaun?></td>
                    <td><?php echo $fix->data_moris?></td>
                    <td width="20px"><?php echo anchor('administrator/fixa/update/'.$fix->id,'<div class="btn btn-sm btn-primary">edit</div>')?></td>

	  	       	<td width="20px"><?php echo anchor('administrator/fixa/delete/'.$fix->id,'<div class="btn btn-sm btn-danger">hamos</i></div>')?></td>
                  </tr>
                  <?php endforeach; ?>
                  <?php } ?>
                 
                </table>
                <p>Total Dadus  : <?php echo $jumlah_data; ?>  </p> 
              </div>
              <!-- /.card-body -->
            </div>
          
          
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer bg-info">
    <div class="float-right d-none d-sm-block">
     
    </div>
  
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>

</body>
</html>
