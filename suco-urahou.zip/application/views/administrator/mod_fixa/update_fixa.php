
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Renova Fixa Familia</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario Renova Dadus Fixa Familia</small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php foreach ($t_fixa_familia as $fix) :?>
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/fixa/asaun_update') ?>">
                <div class="card-body">
                <div class="form-group">
                    <label for="exampleInputPassword1">Id Fixa</label>
                    <input type="text" name="id_fixa" class="form-control" id="exampleInputPassword1"value="<?php echo $fix->id_fixa?>">
                    <?php echo form_error('id_fixa','<div class="text-danger small" ml-3>') ?>
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail1">Id Populasaun</label>
                    <input type="hidden" name="id" value="<?php echo $fix->id ?>">
                    <input type="text" name="id_populasaun" class="form-control" id="exampleInputEmail1" value="<?php echo $fix->id_populasaun?>" >
                    <?php echo form_error('id_populasaun','<div class="text-danger small" ml-3>') ?>
                  </div>
                 
                  <div class="form-group">
                    <label for="exampleInputPassword1">Data Moris </label>
                    <input type="date" name="data_moris" class="form-control" id="exampleInputPassword1"value="<?php echo $fix->data_moris?>">
                    <?php echo form_error('data_moris','<div class="text-danger small" ml-3>') ?>
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
              <?php endforeach; ?>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

