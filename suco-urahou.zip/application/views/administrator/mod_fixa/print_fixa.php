<center><strong> RELATORIO DADUS FIXA FAMILIA IHA SUCO URA-HOU<br>
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table border="1" width="100%" style="text-align:center;">
	
			<tr>
                  <th>No</th>
                    <th> Id Fixa</th>
                    <th>Id Populasaun</th>
                    <th>Data Moris</th>
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_fixa_familia as $fix) : ?>
			<tr>
            <td><?php echo $no++ ?></td>
                   <td><?php echo $fix->id_fixa?></td>
                    <td><?php echo $fix->id_populasaun?></td>
                    <td><?php echo $fix->data_moris?></td>
					
			</tr>
		<?php endforeach; ?>
		
		
	</table>
	<br>
	
  <script type="text/javascript">
     window.print();
   </script>
</body></html>