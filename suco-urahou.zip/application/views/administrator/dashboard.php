
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
         
          </div><!-- /.col -->
         
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <div class="col-md-12">
            <div class="card card-success shadow-sm">
              <div class="card-header">
                <h3 class="card-title"> <strong> Bemvindo mai  Sistema Informasaun Registu Dadus Populasaun iha Suku <strong>Ura-Hou</strong>. ita boot Login hanesan admin.</strong></h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
          <strong class="text-danger"> Favor Klik iha Menu Sorin karuk no Control Iha Okos  hodi maneza ita nia Sistema! </strong>   
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
  
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <!-- <h3>150</h3> -->
              <center><i class="fas fa-3x fa-users mt-2"></i></center>
                <br>
                <p align="center">DADUS POPULASAUN </p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="<?= base_url('administrator/result_populasaun')?>" class="small-box-footer">Hare Dadus.. <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">      
               <center><i class="fas fa-3x fa-people-arrows mt-2"></i></center> 
               <br>
                <p align="center">DADUS FIXA FAMILIA </p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="<?= base_url('administrator/result_fixa')?>" class="small-box-footer">Hare Dadus.. <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
              <center><i class="fas fa-3x fa-graduation-cap mt-2"></i></center> 
               <br>
                <p align="center">Nivel Estudo </p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="<?= base_url('administrator/result_nivel')?>" class="small-box-footer">Hare.. <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
              <center><i class="fas fa-3x fa-church mt-2"></i></center> 
               <br>
                <p align="center">Religiaun </p>
              
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="<?= base_url('administrator/result_reli')?>" class="small-box-footer">Manega <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        
       
     
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer bg-green">
    <!-- <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div> -->
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

