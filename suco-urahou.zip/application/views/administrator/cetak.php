<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<style>
    .line-title{
        border: 0;
        border-style: inset;
        border-top: 1px solid #000;
    }
</style>
</head>
<body>
  
    <table style="width: 100%;">
    <tr>
        <td align="center">
            <span style="line-height: 1.6; font-weight: bold;">
            <img src="<?php echo base_url('assets/uploads/1.jpg')?>" style="position: absolute; width: 80px; height:auto;" class="mr-5"> &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp; 
            &nbsp;  &nbsp;  &nbsp;  &nbsp; 
            <strong> Relatorio Geral Dadus Populasaun Iha Suku Urahou</strong>
           <img src="<?php echo base_url('assets/uploads/1.jpg')?>" style="position: absolute; width: 80px; height:auto; "><br> RELATORIO DADUS Populasaun  <b>Periodo 2019</b>
            </span>
        </td>
    </tr>

    </table> <br> <br>
    <hr class="line-title">
    

    <table class="table table-bordered">
                  <!-- <th>No</th> -->
                  <th> Id Populasaun</th>
                    <th>Naran Completo</th>
                    <th>Fatin Moris</th>
                    <th>Data Moris</th>
                    <th>Hela Sexo</th>
                    <th>Id Religiaun</th>
                    <!-- <th>Id Priodo</th> -->
                    <th> obs</th>
                  <?php 
          $no=1;
          foreach ($populasaun as $pop) : ?>
            
            <tr>
              <!-- <td width="5px"><?php echo $no++ ?></td> -->
              <td><?php echo $pop->id_populasaun?></td>
                    <td><?php echo $pop->nrn_kompletu?></td>
                    <td><?php echo $pop->f_moris?></td>
                    <td><?php echo $pop->d_moris?></td>
                    <td><?php echo $pop->sexo?></td>
                    <td><?php echo $pop->code_reli?></td>
                    <!-- <td></?php echo $pop->id_periodo?></td> -->
                    <td><?php echo $pop->obs?></td>
              
            </tr>
            
          <?php endforeach; ?>  
          <script type="text/javascript">
	window.print();
</script>
    </table>
</body>
</html>
