
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Renova Dadus</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario Renova Mudansa Nivel Estudu</small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php foreach ($t_mud_nivelestudo as $mnest) :?>
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/m_nestudu/asaun_update') ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Id Populasaun</label>
                    <input type="hidden" name="id" value="<?php echo $mnest->id ?>">
                    <input type="text" name="id_populasaun" class="form-control" id="exampleInputEmail1" value="<?php echo $mnest->id_populasaun?>" >
                    <?php echo form_error('id_populasaun','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Id Nivel Estudu</label>
                    <input type="text" name="id_nivel" class="form-control" id="exampleInputPassword1"value="<?php echo $mnest->id_nivel?>">
                    <?php echo form_error('id_nivel','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Data</label>
                    <input type="date" name="data_muda" class="form-control" id="exampleInputPassword1"value="<?php echo $mnest->data_muda?>" >
                    <?php echo form_error('data_muda','<div class="text-danger small" ml-3>') ?>
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
              <?php endforeach; ?>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

