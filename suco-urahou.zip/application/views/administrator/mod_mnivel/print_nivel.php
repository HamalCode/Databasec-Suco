<center><strong> RELATORIO DADUS FIXA FAMILIA IHA SUCO URA-HOU<br>
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table border="1" width="100%" style="text-align:center;">
	
			<tr>
                  <th>No</th>
                  <th> Id Populasaun</th>
                    <th>Id Nivel Estudo</th>
                    <th>Data Muda</th>
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_mud_nivelestudo as $mnest) : ?>
			<tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $mnest->id_populasaun?></td>
                    <td><?php echo $mnest->id_nivel?></td>
                    <td><?php echo $mnest->data_muda?></td>
					
			</tr>
		<?php endforeach; ?>
		
		
	</table>
	<br>
	
  <script type="text/javascript">
     window.print();
   </script>
</body></html>