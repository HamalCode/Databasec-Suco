<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!doctype html>
<html>

<head>
    <title>DATA POPULASAUN</title>
</head>

<body>
    <p><?php echo $msg; ?></p>
    <p><?php echo anchor('administrator/registo', 'Fila'); ?></p>

</body>

</html>