
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Renova Religiaun</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario Renova Religiaun</small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php foreach ($t_religiaun as $rel) :?>
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/religiaun/asaun_update') ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Id Religiaun</label>
                    <input type="hidden" name="id" value="<?php echo $rel->id ?>">
                    <input type="text" name="code_reli" class="form-control" id="exampleInputEmail1" value="<?php echo $rel->code_reli?>" placeholder=" Codigo">
                    <?php echo form_error('code_reli','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Naran Religiaun</label>
                    <input type="text" name="nrn_reli" class="form-control" id="exampleInputPassword1"value="<?php echo $rel->nrn_reli?>" placeholder="Religiaun">
                    <?php echo form_error('nrn_reli','<div class="text-danger small" ml-3>') ?>
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
              <?php endforeach; ?>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

