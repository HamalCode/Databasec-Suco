<center><strong> RELATORIO DADUS RELIGIAUN IHA SUCO URA-HOU<br>
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table border="1" width="100%" style="text-align:center;">
	
			<tr>
                <th>No</th>
                <th> Id Religiaun</th>
                    <th>Naran Religiaun</th>
                   
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_religiaun as $rel) : ?>
			<tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $rel->code_reli?></td>
                    <td><?php echo $rel->nrn_reli?></td>
					
			</tr>
		<?php endforeach; ?>
		
		
	</table>
	<br>
	
  <script type="text/javascript">
     window.print();
   </script>
</body></html>