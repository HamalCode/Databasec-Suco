<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print estudante</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
</head>
<body>
    <div class="container col-md-12">
        <div class="row">
            <div class="col-md-2">
                <form action="" id="form_laporan">
                    <select name="" id="periodo" class="form-control mt-2">
                        <option value="0">Hare Data Geral</option>
                        <?php foreach ($periodo as $row) :?>
                            <option value="<?php echo $row->id_periodo?>"><?php echo $row->tinan?></option>
                        <?php endforeach?>
                    </select>
                    <br>
                    <button type="submit" class="btn btn-primary mb-2">Hare data</button>
                </form>
            </div>
           
        </div>
        <div class="col-md-12">
                <div id="result"></div>
            </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
       $(document).ready(function() {
            $("#form_laporan").submit(function(e){
                e.preventDefault();
                var id_periodo = $("#periodo").val();
                // console.log(id_periodo);
                var url = "<?= site_url('administrator/cetak_filter/filter/')?>" + id_periodo;
                $('#result').load(url);
            })
       });
    </script>
</body>
</html>