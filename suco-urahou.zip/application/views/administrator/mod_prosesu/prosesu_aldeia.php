<!DOCTYPE html>
<html lang="en">

<body class="hold-transition sidebar-mini">
<div class="wrapper">
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dadus Aldeia</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header bg-info">
                <h3 class="card-title">Tabela Registo Aldeia</h3>
               
              </div>
                <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <!-- <th>#</th> -->
                    <th> Id Aldeia</th>
                    <th>Aldeia</th>
                    
                  </tr>
                  </thead>
                  
                  <tr>
                  <?php 
	           	$no =1;
	          	foreach ($t_aldeia as $ald):
	            	 ?>
                 <!-- <td width="20px"></?php echo $no++ ?></td> -->
                    <td><?php echo $ald->code_aldeia?></td>
                    <td><?php echo $ald->nrn_aldeia?></td>
                   	 </tr>
                  <?php endforeach; ?>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
          
          
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer bg-info">
    <div class="float-right d-none d-sm-block">
     
    </div>
  
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>

</body>
</html>
