
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Formulario </h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario Populasaun</small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/populasaun/asaun_input') ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Id Populasaun</label>
                    <input type="text" name="id_populasaun" class="form-control" id="exampleInputEmail1" placeholder=" id">
                    <?php echo form_error('id_populasaun','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Naran Kompleto</label>
                    <input type="text" name="nrn_kompletu" class="form-control" id="exampleInputEmail1" placeholder=" naran">
                    <?php echo form_error('nrn_kompletu','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Fatin Moris</label>
                    <input type="text" name="f_moris" class="form-control" id="exampleInputEmail1" placeholder=" fatin moris">
                    <?php echo form_error('f_moris','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Data Moris</label>
                    <input type="date" name="d_moris" class="form-control" id="exampleInputEmail1">
                    <?php echo form_error('d_moris','<div class="text-danger small" ml-3>') ?>
                  </div>
                  
                  <div class="form-group">
                    <label>Sexo</label>
                    <select name="sexo" class="form-control">
                      <option value="">--hili sexo--</option>
                      <option>Mane</option>
                      <option>Feto</option>
                    </select>
                    <?php echo form_error('sexo','<div class="text-danger small ml-3">','</div>') ?>
                  </div>
                  <div class="form-group">
                    <label>Id Religiaun</label>
                    <select name="code_reli" class="form-control">
                        <option value="">--Hili--</option>
                        <?php foreach($t_religiaun as $rel) : ?>
                        <option value="<?php echo $rel->code_reli ?>"><?php echo $rel->code_reli ?></option>
                    <?php endforeach ?>
                    </select>
                    <?php echo form_error('code_reli','<div class="text-danger small ml-3">','</div>') ?>
                </div>
                <div class="form-group">
                <label>ID PERIODO</label>
                <select name="id_periodo" class="form-control">
                  <option value="">hili..</option>
                  <?php foreach($periodo as $per) : ?>
                  <option value="<?php echo $per->id_periodo ?>"><?php echo $per->id_periodo ?></option>
                <?php endforeach ?>
                </select>
                <?php echo form_error('id_periodo','<div class="text-danger small ml-3">','</div>') ?>
              </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Obs</label>
                    <input type="text" name="obs" class="form-control" id="exampleInputPassword1" placeholder="Observasaun" >
                    <!-- <?php echo form_error('data_moris','<div class="text-danger small" ml-3>') ?> -->
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

