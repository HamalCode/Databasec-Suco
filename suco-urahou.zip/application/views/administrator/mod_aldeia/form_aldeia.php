
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Formulario Aldeia</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario Registo Aldeia</small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/aldeia/asaun_input') ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Codigo Aldeia</label>
                    <input type="text" name="code_aldeia" class="form-control" id="exampleInputEmail1" placeholder=" Codigo">
                    <?php echo form_error('code','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Naran Aldeia</label>
                    <input type="text" name="nrn_aldeia" class="form-control" id="exampleInputPassword1" placeholder="Aldeia">
                    <?php echo form_error('nrn_aldeia','<div class="text-danger small" ml-3>') ?>
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

