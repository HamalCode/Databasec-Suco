<center><strong> RELATORIO DADUS REGISTO ALDEIA </strong> <br>
            
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table border="1" width="100%" style="text-align:center;">
	
			<tr>
			<th>NO</th>
			<th>Codigo Aldeia</th>
			<th>Naran Aldeia</th>
		
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_aldeia as $pop) : ?>
			<tr>
			     <td><?php echo $no++ ?></td>
                   <td><?php echo $pop->code_aldeia?></td>
                    <td><?php echo $pop->nrn_aldeia?></td>
                    
					
			</tr>
		<?php endforeach; ?>
		
	</table>
</body></html>