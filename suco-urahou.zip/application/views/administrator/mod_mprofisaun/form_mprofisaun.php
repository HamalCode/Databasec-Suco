
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Mudansa Profisaun</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario Mudansa Profisaun </small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/mprofisaun/asaun_input') ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Id Profisaun</label>
                    <input type="text" name="id_profisaun" class="form-control" id="exampleInputEmail1" placeholder="Id Profisaun">
                    <?php echo form_error('id_profisaun','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Naran Profisaun</label>
                    <input type="text" name="nrn_profisaun" class="form-control" id="exampleInputPassword1" placeholder="profisaun">
                    <?php echo form_error('nrn_profisaun','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label>Id Nivel</label>
                    <select name="id_nivel" class="form-control">
                        <option value="">Nivel</option>
                        <?php foreach($t_mud_nivelestudo as $mnest) : ?>
                        <option value="<?php echo $mnest->id_nivel ?>"><?php echo $mnest->id_nivel ?></option>
                    <?php endforeach ?>
                    </select>
                    <?php echo form_error('id_nivel','<div class="text-danger small ml-3">','</div>') ?>
                </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1"> Data Mudansa</label>
                    <input type="date" name="data_muda" class="form-control" id="exampleInputPassword1" placeholder="data muda">
                    <?php echo form_error('data_muda','<div class="text-danger small" ml-3>') ?>
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

