
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Formulario Mudasa Estatuto</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario  Mudansa Estatuto</small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/mstatuto/asaun_input') ?>">
                <div class="card-body">
                <div class="form-group">
                    <label>Id Populasaun</label>
                    <select name="id_populasaun" class="form-control">
                        <option value="">--Hili--</option>
                        <?php foreach($t_populasaun as $pop) : ?>
                        <option value="<?php echo $pop->id_populasaun ?>"><?php echo $pop->id_populasaun ?></option>
                    <?php endforeach ?>
                    </select>
                    <?php echo form_error('id_populasaun','<div class="text-danger small ml-3">','</div>') ?>
                </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1"> Id Mudansa Statuto</label>
                    <input type="text" name="id_mstatuto" class="form-control" id="exampleInputPassword1" placeholder="Id m-statuto">
                    <?php echo form_error('id_mstatuto','<div class="text-danger small" ml-3>') ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1"> Data Mudansa</label>
                    <input type="date" name="data_muda" class="form-control" id="exampleInputPassword1" >
                    <?php echo form_error('data_muda','<div class="text-danger small" ml-3>') ?>
                  </div>
                 
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

