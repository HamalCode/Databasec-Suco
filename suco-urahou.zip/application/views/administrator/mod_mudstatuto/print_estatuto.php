<center><strong> RELATORIO DADUS ESTATUTO SUCO URA-HOU<br>
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table border="1" width="100%" style="text-align:center;">
	
			<tr>
                <th>No</th>
            <th> Id Populasaun</th>
            <th>Id Muda-statuto</th>
             <th>Data Mudansa</th>
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_mud_statuto as $msta) : ?>
			<tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $msta->id_populasaun?></td>
                    <td><?php echo $msta->id_mstatuto?></td>
                    <td><?php echo $msta->data_muda?></td>
					
			</tr>
		<?php endforeach; ?>
		
		
	</table>
	<br>
	
  <script type="text/javascript">
     window.print();
   </script>
</body></html>