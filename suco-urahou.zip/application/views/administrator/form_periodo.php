
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Formulario</h1>
          </div>
         
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario Registo Tinan Periodo</small></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form id="quickForm" method="post" action="<?php echo base_url('administrator/periodo/asaun_input') ?>">
			  <div class="form-group ml-2">
			<label>Id Periodo</label>
			<input type="text" name="id_periodo" placeholder="id periodo" class="form-control">
			<?php echo form_error('id_periodo','<div class="text-danger small" ml-3>') ?>

		</div>

		<div class="form-group ml-2">
			<label> Tinan Periodo</label>
			<input type="text" name="tinan" placeholder="tinan periodo" class="form-control">
			<?php echo form_error('tinan','<div class="text-danger small" ml-3>') ?>
		</div> 
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Rai</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 

