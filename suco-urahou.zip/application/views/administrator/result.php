<table class="table table-striped">
    <tr>
        <!-- <th>No</th> -->
        <th> Id Populasaun</th>
                    <th>Naran Completo</th>
                    <th>Fatin Moris</th>
                    <th>Data Moris</th>
                    <th>Hela Sexo</th>
                    <th>Id Religiaun</th>
                    <!-- <th>Id Priodo</th> -->
                    <th> obs</th>
       
    </tr>
    <?php $no=1; foreach ($populasaun as $pop) :?>
            <tr>
                <!-- <td><?php echo $no++; ?></td> -->
                <td><?php echo $pop->id_populasaun?></td>
                    <td><?php echo $pop->nrn_kompletu?></td>
                    <td><?php echo $pop->f_moris?></td>
                    <td><?php echo $pop->d_moris?></td>
                    <td><?php echo $pop->sexo?></td>
                    <td><?php echo $pop->code_reli?></td>
                    <!-- <td></?php echo $pop->id_periodo?></td> -->
                    <td><?php echo $pop->obs?></td>
               
            </tr>
            
        <?php endforeach?>  
</table>
<br>

<a href="<?= site_url('administrator/cetak_filter/cetak/'.$id_periodo)?>" target="_blank" class="btn btn-danger">Print</a>



