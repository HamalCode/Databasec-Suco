<?php
Class fixa extends CI_Controller{
    public function index()
	{
		$getData = $this->fixa_model->get();

        $data = [
            
            'jumlah_data' => $getData->num_rows()
        ];
		
		$data['t_fixa_familia']  =$this->fixa_model->fosai_dadus('t_fixa_familia')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_fixa/fixa',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id'	             =>set_value('id'),
            'id_fixa'	      =>set_value('id_fixa'),
			'id_populasaun'	        =>set_value('id_populasaun'),
			'data_moris'	      =>set_value('data_moris'),
		);
		$data['t_populasaun']  =$this->fixa_model->fosai_dadus('t_populasaun')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_fixa/form_fixa',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
                'id_fixa'   =>$this->input->post('id_fixa',TRUE),
				'id_populasaun'           =>$this->input->post('id_populasaun',TRUE),
				'data_moris'   =>$this->input->post('data_moris',TRUE),
			);
			$this->fixa_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Fixa Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/fixa');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('id_populasaun','id','required',[
			'required' =>'Favor Prense ID populasaun'
		]);
		$this->form_validation->set_rules('id_fixa','id_fixa','required',[
			'required' =>'Favor prense Id '
		]);
		$this->form_validation->set_rules('data_moris','data_moris','required',[
			'required' =>'Favor muda data'
		]);
	}

    public function update($id)
	{
		$where = array('id' => $id);
		$data['t_fixa_familia']=$this->fixa_model->edit_data($where,'t_fixa_familia')->result();
        $data['t_populasaun']=$this->fixa_model->edit_data($where,'t_populasaun')->result();
        $data['t_fixa_familia'] = $this->db->query("select * from t_fixa_familia fix, t_populasaun pop where fix.id_populasaun=pop.id_populasaun and pop.id='$id'")->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_fixa/update_fixa',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id = $this->input->post('id');
        $id_fixa = $this->input->post('id_fixa');
		$id_populasaun   = $this->input->post('id_populasaun');
		$data_moris = $this->input->post('data_moris');

		$data = array(
            'id_fixa'       => $id_fixa,
			'id_populasaun'      => $id_populasaun,
			'data_moris'       => $data_moris
		);

		$where = array(
			'id' =>$id
		);
		$this->fixa_model->update_data($where,$data,'t_fixa_familia');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus  Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/fixa');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->fixa_model->hamos_data($where, 't_fixa_familia');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus  Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/fixa');
	}
    public function print()
	{
		$data['t_fixa_familia']= $this->fixa_model->fosai_dadus('t_fixa_familia')->result();
        $this->load->view('administrator/mod_fixa/print_fixa',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_fixa_familia']=$this->fixa_model->fosai_dadus("t_fixa_familia")->result();
        $this->load->view('administrator/relafixa_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_fixa.pdf", array('attachment'=>0));
     }

}