<?php
Class dashboard extends CI_controller{
    function __construct(){
		parent::__construct();
		if(!isset($this->session->userdata['username'])){
			$this->session->set_flashdata('Mensagem','<div class="alert alert-danger alert-dismissible fade show" role="alert">
					Favor login Administrator!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button> 
				</div>');
			redirect('administrator/auth');
		}
	}
 public function index()
 
        {
            
        $this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/dashboard');
		$this->load->view('templates_administrator/footer');
        }
}