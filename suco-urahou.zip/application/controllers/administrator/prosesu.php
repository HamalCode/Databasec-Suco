<?php 
class prosesu extends CI_Controller{
	public function index()
	{
        $getData = $this->prosesu_model->get();

        $data = [
            
            'jumlah_data' => $getData->num_rows()
        ];
		
		//pagination
		$this->load->library('pagination');
		//config
		$config['base_url']= 'http://localhost/suco/administrator/prosesu/index';
		$config['total_rows'] = $this->prosesu_model->countAllpopulasaun();
		// var_dump($config['total_rows']); die; cek total datta table.
		$config['per_page'] = 8;
		$config['num_links']=5;
		//style
		$config['full_tag_open']='<nav"><ul class="pagination justify-content-center">';
		$config['full_tag_close']=' </ul></nav>';

		$config['first_link'] ='First';
		$config['first_tag_open']=' <li class="page-item">';
		$config['first_tag_close']=' </li>';

		$config['last_link'] ='Last';
		$config['last_tag_open']=' <li class="page-item">';
		$config['last_tag_close']=' </li>';
		
		$config['next_link'] ='&raquo';
		$config['next_tag_open']=' <li class="page-item">';
		$config['next_tag_close']=' </li>';

		$config['prev_link'] ='&laquo';
		$config['prev_tag_open']=' <li class="page-item">';
		$config['prev_tag_close']=' </li>';

		$config['cur_tag_open']=' <li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close']='</a> </li>';

		$config['num_tag_open']=' <li class="page-item ">';
		$config['num_tag_close']=' </li>';

		// Produces: class="myclass"
       $config['attributes'] = array('class' => 'page-link');

		//initialize
		$this->pagination->initialize($config);
		
	
       $data['start'] = $this->uri->segment(4);
		$data['t_populasaun'] =$this->populasaun_model->fosai_dadus($config['per_page'], $data['start'])->result();
		$data['t_aldeia'] = $this->aldeia_model->fosai_dadus('t_aldeia')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/prosesu',$data);
		$this->load->view('templates_administrator/footer');
		
	}
	public function detail($id)
	{
		$data['detail']= $this->populasaun_model->foti_id_populasaun($id);
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/populasaun_detail',$data);
		$this->load->view('templates_administrator/footer');
	}

	
	
	public function amenta_populasaun()
	{
      //pagination
		$this->load->library('pagination');
		//config
		$config['base_url']= 'http://localhost/suco/administrator/populasaun/index';
		$config['total_rows'] = $this->procesu_model->countAllpopulasaun();
		// var_dump($config['total_rows']); die; cek total datta table.
		$config['per_page'] = 8;
		$config['num_links']=5;
		//style
		$config['full_tag_open']='<nav"><ul class="pagination justify-content-center">';
		$config['full_tag_close']=' </ul></nav>';

		$config['first_link'] ='First';
		$config['first_tag_open']=' <li class="page-item">';
		$config['first_tag_close']=' </li>';

		$config['last_link'] ='Last';
		$config['last_tag_open']=' <li class="page-item">';
		$config['last_tag_close']=' </li>';
		
		$config['next_link'] ='&raquo';
		$config['next_tag_open']=' <li class="page-item">';
		$config['next_tag_close']=' </li>';

		$config['prev_link'] ='&laquo';
		$config['prev_tag_open']=' <li class="page-item">';
		$config['prev_tag_close']=' </li>';

		$config['cur_tag_open']=' <li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close']='</a> </li>';

		$config['num_tag_open']=' <li class="page-item ">';
		$config['num_tag_close']=' </li>';

		// Produces: class="myclass"
       $config['attributes'] = array('class' => 'page-link');

		//initialize
		$this->pagination->initialize($config);
		
	
       $data['start'] = $this->uri->segment(4);
		$data['t_aldeia'] = $this->aldeia_model->fosai_dadus('t_aldeia')->result();
       
		// $data['t_municipio']  =$this->municipio_model->fosai_dadus('t_municipio')->result();
		// $data['t_posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
	
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		// $this->load->view('administrator/form_populasaun',$data);
		$this->load->view('templates_administrator/footer');
	}
	public function asaun_amenta_populasaun()
	{
        
		$this->_rules();
		if($this->form_validation->run()==FALSE){
			$this->amenta_populasaun();
		}else{
			$nrep                            =$this->input->post('nrep');
			$naran                         =$this->input->post('naran');
			$sexo                                 =$this->input->post('sexo');
			$status                                =$this->input->post('status');
			$data_moris                             =$this->input->post('data_moris');
			$fatin_moris                             =$this->input->post('fatin_moris');
            $profisaun                             =$this->input->post('profisaun');
			$no_eleitoral                              =$this->input->post('no_eleitoral');
			$no_fixa                              =$this->input->post('no_fixa');		
			$code_aldeia                            =$this->input->post('code_aldeia');
			$hela_fatin                               =$this->input->post('hela_fatin');
			// $foto                              =$_FILES['foto'];
			// if ($foto=''){}else{
			// 	$config['upload_path'] ='./assets/uploads';
			// 	$config['allowed_types'] = 'jpg|png|jpeg|gif';

			// 	$this->load->library('upload',$config);
			// 	if(!$this->upload->do_upload('foto')){
			// 		echo "faila upload";die();
			// 	}else{
			// 		$foto=$this->upload->data('file_name');
			// 	}
			// }
		$data = array(
			'nrep'                                    =>$nrep,
			'naran'						          	  =>$naran,
			'sexo'                                     =>$sexo,
			'status'                                   =>$status,
			'data_moris'                                 =>$data_moris,
			'fatin_moris'                                =>$fatin_moris,
            'profisaun'                                =>$profisaun,
			'no_eleitoral'                              =>$no_eleitoral,
			'no_fixa'                                   =>$no_fixa,
						
			'code_aldeia'                               =>$code_aldeia,
			'hela_fatin'                               =>$hela_fatin
			// 'foto'                                     =>$foto
			
		);
		$this->populasaun_model->insert_data($data,'t_populasaun');
					$this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus Populasaun Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/populasaun');
	}
  }
  public function _rules()
  {
  	$this->form_validation->set_rules('nrep','nrep','required',['required' => 'code populasaun Sedauk Iha!']);

  	$this->form_validation->set_rules('naran','naran','required',['required' => 'Naran Sedauk Iha!']);
	  $this->form_validation->set_rules('sexo','sexo','required',['required' => 'Sexo Sedauk Iha!']);
  	$this->form_validation->set_rules('status','status','required',['required' => 'status Sedauk Iha!']);  
  	$this->form_validation->set_rules('data_moris','data_moris','required',['required' => 'data moris Sedauk Iha!']);
  	$this->form_validation->set_rules('fatin_moris','fatin_moris','required',['required' => 'Fatin moris Sedauk Iha!']);
      $this->form_validation->set_rules('profisaun','profisaun','required',['required' => 'Fatin moris Sedauk Iha!']);
  	$this->form_validation->set_rules('no_eleitoral','no_eleitoral','required',['required' => 'eleitoral Sedauk Iha!']);
  	$this->form_validation->set_rules('no_fixa','no_fixa','required',['required' => 'No. Fixa Sedauk  Iha!']);
	$this->form_validation->set_rules('code_aldeia','code_aldeia','required',['required' => ' code aldeia Sedauk Iha!']);
    $this->form_validation->set_rules('hela_fatin','hela_fatin','required',['required' => 'Hela fatin Sedauk Iha!']);
  }
 	
}
