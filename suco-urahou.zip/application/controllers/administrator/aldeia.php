<?php
Class aldeia extends CI_Controller{
    public function index()
	{
		
		$getData = $this->aldeia_model->get();

        $data = [
            
            'jumlah_data' => $getData->num_rows()
        ];
		 $data['start'] = $this->uri->segment(4);
		$data['t_aldeia']  =$this->aldeia_model->fosai_dadus('t_aldeia')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_aldeia/aldeia',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id'	             =>set_value('id'),
			'code_aldeia'	        =>set_value('code_aldeia'),
			'nrn_aldeia'	      =>set_value('nrn_aldeia'),
		);
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_aldeia/form_aldeia',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'code_aldeia'           =>$this->input->post('code_aldeia',TRUE),
				'nrn_aldeia'   =>$this->input->post('nrn_aldeia',TRUE),
			);
			$this->aldeia_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Aldeia Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/aldeia');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('code_aldeia','id','required',[
			'required' =>'Favor Prense ID aldeia'
		]);
		$this->form_validation->set_rules('nrn_aldeia','nrn_aldeia','required',[
			'required' =>'Favor prense naran Aldeia'
		]);
	}

    public function update($id)
	{
		$where = array('id' => $id);
		$data['t_aldeia']=$this->aldeia_model->edit_data($where,'t_aldeia')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_aldeia/update_aldeia',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id = $this->input->post('id');
		$code_aldeia   = $this->input->post('code_aldeia');
		$nrn_aldeia = $this->input->post('nrn_aldeia');

		$data = array(
			'code_aldeia'      => $code_aldeia,
			'nrn_aldeia' => $nrn_aldeia
		);

		$where = array(
			'id' =>$id
		);
		$this->aldeia_model->update_data($where,$data,'t_aldeia');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus Aldeia Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/aldeia');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->aldeia_model->hamos_data($where, 't_aldeia');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus Aldeia Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/aldeia');
	}
    public function print()
	{
		$data['t_aldeia']= $this->aldeia_model->fosai_dadus('t_aldeia')->result();
        $this->load->view('administrator/mod_output/print_aldeia',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_aldeia']=$this->aldeia_model->fosai_dadus("t_aldeia")->result();
        $this->load->view('administrator/mod_output/relaldeia_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_aldeia.pdf", array('attachment'=>0));
     }

}