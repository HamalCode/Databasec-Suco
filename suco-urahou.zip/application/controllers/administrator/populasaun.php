<?php
Class populasaun extends CI_Controller{
    public function index()
	{
		$getData = $this->populasaun_model->get();

        $data = [
            
            'jumlah_data' => $getData->num_rows()
        ];

	$data['t_populasaun']  =$this->populasaun_model->fosai_dadus('t_populasaun')->result();
	$data['t_religiaun']  =$this->populasaun_model->fosai_dadus('t_religiaun')->result();
	
	$this->load->view('templates_administrator/header');
	$this->load->view('templates_administrator/sidebar');
	$this->load->view('administrator/mod_popula/populasaun',$data);
	$this->load->view('templates_administrator/footer');
}

public function input()
{
	
		$data['t_populasaun']  =$this->populasaun_model->fosai_dadus('t_populasaun')->result();
		$data['t_religiaun']  =$this->populasaun_model->fosai_dadus('t_religiaun')->result();
		$data['periodo'] = $this->periodo_model->fosai_dadus('periodo')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_popula/form_populasaun',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
                'id_populasaun'   =>$this->input->post('id_populasaun',TRUE),
				'nrn_kompletu'           =>$this->input->post('nrn_kompletu',TRUE),
				'f_moris'   =>$this->input->post('f_moris',TRUE),
				'd_moris'   =>$this->input->post('d_moris',TRUE),
				'sexo'           =>$this->input->post('sexo',TRUE),
				'code_reli'   =>$this->input->post('code_reli',TRUE),
				'id_periodo'   =>$this->input->post('id_periodo',TRUE),
				'obs'   =>$this->input->post('obs',TRUE),
				
			);
			$this->populasaun_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus populasaun Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/populasaun');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('id_populasaun','id','required',[
			'required' =>'Favor Prense ID populasaun'
		]);
		$this->form_validation->set_rules('nrn_kompletu','nrn_kompletu','required',[
			'required' =>'Favor prense naran '
		]);
		$this->form_validation->set_rules('f_moris','f_moris','required',[
			'required' =>'Favor prense fatin moris'
		]);
		$this->form_validation->set_rules('d_moris','d_moris','required',[
			'required' =>'Favor prense data moris'
		]);
		$this->form_validation->set_rules('sexo','sexo','required',[
			'required' =>'Favor prense sexo'
		]);
		$this->form_validation->set_rules('code_reli','code_reli','required',[
			'required' =>'Favor prense id religiaun'
		]);
		$this->form_validation->set_rules('id_periodo','id_periodo','required',[
			'required' =>'Favor prense id periodo'
		]);
		
	}

	public function update($id)
	{
		$where = array('id' => $id);
		$data['t_populasaun'] = $this->db->query("select * from t_populasaun pop, t_religiaun rel where pop.code_reli=rel.code_reli and pop.id='$id'")->result();
		$data['t_populasaun']=$this->populasaun_model->edit_data($where,'t_populasaun')->result();
		$data['t_religiaun']=$this->populasaun_model->edit_data($where,'t_religiaun')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_popula/update_populasaun',$data);
		$this->load->view('templates_administrator/footer');
	}

	public function asaun_update()
	{
		$id = $this->input->post('id');
        $id_populasaun = $this->input->post('id_populasaun');
		$nrn_kompletu   = $this->input->post('nrn_kompletu');
		$f_moris = $this->input->post('f_moris');
		$d_moris = $this->input->post('d_moris');
		$d_moris = $this->input->post('d_moris');
		$sexo = $this->input->post('sexo');
		$code_reli = $this->input->post('code_reli');
		$obs = $this->input->post('obs');

		$data = array(
            'id_populasaun'       => $id_populasaun,
			'nrn_kompletu'      => $nrn_kompletu,
			'f_moris'       => $f_moris,
			'd_moris'       => $d_moris,
			'sexo'      => $sexo,
			'code_reli'       => $code_reli,
			'obs'       => $obs
		);

		$where = array(
			'id' =>$id
		);
		$this->populasaun_model->update_data($where,$data,'t_populasaun');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus  Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/populasaun');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->populasaun_model->hamos_data($where, 't_populasaun');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus  Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/populasaun');
	}
    public function print()
	{
		$data['t_populasaun']= $this->populasaun_model->fosai_dadus('t_populasaun')->result();
        $this->load->view('administrator/mod_output/print_populasaun',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_populasaun']=$this->populasaun_model->fosai_dadus("t_populasaun")->result();
        $this->load->view('administrator/mod_output/populasaun_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_populasaun.pdf", array('attachment'=>0));
     }

}