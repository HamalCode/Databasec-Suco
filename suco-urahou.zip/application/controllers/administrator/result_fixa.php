<?php
Class result_fixa extends CI_Controller{
    public function index()
	{
		
		$data['t_fixa_familia']  =$this->fixa_model->fosai_dadus('t_fixa_familia')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_fixa/result_fixa',$data);
		$this->load->view('templates_administrator/footer');
	}
}