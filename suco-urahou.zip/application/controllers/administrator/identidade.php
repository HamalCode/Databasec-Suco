<?php
Class identidade Extends CI_controller{
	public function index()
	{
		$data['t_identidade']=$this->identidade_model->fosai_dadus('t_identidade')->result();
		$this->load->view('administrator/header');
		$this->load->view('administrator/sidebar');
		$this->load->view('administrator/identidade', $data);
		$this->load->view('administrator/footer');
	}
}