<?php
Class religiaun extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_religiaun']  =$this->religiaun_model->fosai_dadus('t_religiaun')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_religiaun/religiaun',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id'	             =>set_value('id'),
			'code_reli'	        =>set_value('code_reli'),
			'nrn_reli'	      =>set_value('nrn_reli'),
		);
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_religiaun/form_religiaun',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'code_reli'           =>$this->input->post('code_reli',TRUE),
				'nrn_reli'           =>$this->input->post('nrn_reli',TRUE),
			);
			$this->religiaun_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Religiaun Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/religiaun');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('code_reli','id','required',[
			'required' =>'Favor Prense Id Religiaun'
		]);
		$this->form_validation->set_rules('nrn_reli','nrn_reli','required',[
			'required' =>'Favor prense naran Religiaun'
		]);
	}

    public function update($id)
	{
		$where = array('id' => $id);
		$data['t_religiaun']=$this->religiaun_model->edit_data($where,'t_religiaun')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_religiaun/update_religiaun',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id = $this->input->post('id');
		$code_reli   = $this->input->post('code_reli');
		$nrn_reli = $this->input->post('nrn_reli');

		$data = array(
			'code_reli'      => $code_reli,
			'nrn_reli'       => $nrn_reli
		);

		$where = array(
			'id' =>$id
		);
		$this->religiaun_model->update_data($where,$data,'t_religiaun');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus Religiaun Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/religiaun');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->religiaun_model->hamos_data($where, 't_religiaun');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus Aldeia Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/aldeia');
	}
    public function print()
	{
		$data['t_religiaun']= $this->religiaun_model->fosai_dadus('t_religiaun')->result();
         $this->load->view('administrator/mod_religiaun/print_religiaun',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_religiaun']=$this->religiaun_model->fosai_dadus("t_religiaun")->result();
        $this->load->view('administrator/relareli_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_religiaun.pdf", array('attachment'=>0));
     }

}