<?php
Class prosesu_estatutu extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_mud_statuto']  =$this->mstatuto_model->fosai_dadus('t_mud_statuto')->result();
		$data['t_populasaun']  =$this->mstatuto_model->fosai_dadus('t_populasaun')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_prosesu/prosesu_estatutu',$data);
		$this->load->view('templates_administrator/footer');
	}

}