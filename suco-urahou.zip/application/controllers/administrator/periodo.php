<?php
Class periodo extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['periodo']  =$this->periodo_model->fosai_dadus('periodo')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/periodo',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id_periodo'	 =>set_value('id_periodo'),
			'tinan'	        =>set_value('tinan'),
			
		);
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/form_periodo',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'id_periodo'  =>$this->input->post('id_periodo',TRUE),
				'tinan'   =>$this->input->post('tinan',TRUE),
			);
			$this->periodo_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Tinan Periodo Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/periodo');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('id_periodo','id','required',[
			'required' =>'Favor Hili ID Periodo'
		]);
		$this->form_validation->set_rules('tinan','tinan','required',[
			'required' =>'Favor prense Tinan Periodo'
		]);
	}

    public function update($id)
	{
		$where = array('id' => $id);
		$data['periodo']=$this->periodo_model->edit_data($where,'periodo')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/update_periodo',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id_periodo = $this->input->post('id_periodo');
		$tinan     = $this->input->post('tinan');
		

		$data = array(
			'id_periodo'      => $id_periodo,
			'tinan' => $tinan
		);

		$where = array(
			'id' =>$id
		);
		$this->perodo_model->update_data($where,$data,'periodo');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Tinan Periodo Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/periodo');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->periodo_model->hamos_data($where, 'periodo');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus periodo Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/periodo');
	}
    public function print()
	{
		$data['periodo']= $this->aldeia_model->fosai_dadus('periodo')->result();
        $this->load->view('administrator/prinperiodo',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['periodo']=$this->aldeia_model->fosai_dadus("periodo")->result();
        $this->load->view('administrator/relaldeia_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_aldeia.pdf", array('attachment'=>0));
     }

}