<?php
Class m_nestudu extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_mud_nivelestudo']  =$this->m_nestudu_model->fosai_dadus('t_mud_nivelestudo')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mnivel/m_nestudu',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id'	             =>set_value('id'),
			'id_populasaun'	        =>set_value('id_populasaun'),
			'id_nivel'	      =>set_value('id_nivel'),
			'data_muda'	      =>set_value('data_muda'),
		);
		$data['t_populasaun']  =$this->m_nestudu_model->fosai_dadus('t_populasaun')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mnivel/form_mnivel',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'id_populasaun'           =>$this->input->post('id_populasaun',TRUE),
				'id_nivel'   =>$this->input->post('id_nivel',TRUE),
				'data_muda'   =>$this->input->post('data_muda',TRUE),
			);
			$this->m_nestudu_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Muda Nivel Estudu Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/m_nestudu');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('id_populasaun','id','required',[
			'required' =>'Favor Prense ID populasaun'
		]);
		$this->form_validation->set_rules('id_nivel','id_nivel','required',[
			'required' =>'Favor prense Id nivel estudu '
		]);
		$this->form_validation->set_rules('data_muda','data_muda','required',[
			'required' =>'Favor muda data'
		]);
	}

    public function update($id)
	{
		$where = array('id' => $id);
		$data['t_mud_nivelestudo']=$this->m_nestudu_model->edit_data($where,'t_mud_nivelestudo')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mnivel/update_mnivel',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id = $this->input->post('id');
		$id_populasaun   = $this->input->post('id_populasaun');
		$id_nivel = $this->input->post('id_nivel');
		$data_muda = $this->input->post('data_muda');

		$data = array(
			'id_populasaun'      => $id_populasaun,
			'id_nivel'       => $id_nivel,
			'data_muda'       => $data_muda
		);

		$where = array(
			'id' =>$id
		);
		$this->m_nestudu_model->update_data($where,$data,'t_mud_nivelestudo');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus Muda Nivel Estudu Susesu renova!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/m_nestudu');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->m_nestudu_model->hamos_data($where, 't_mud_nivelestudo');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus muda Nivel estudu Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/m_nestudu');
	}
    public function print()
	{
		$data['t_mud_nivelestudo']= $this->m_nestudu_model->fosai_dadus('t_mud_nivelestudo')->result();
        $this->load->view('administrator/mod_mnivel/print_nivel',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_mud_nivelestudo']=$this->m_nestudu_model->fosai_dadus("t_mud_nivelestudo")->result();
        $this->load->view('administrator/relamstatuto_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_mstatuto.pdf", array('attachment'=>0));
     }

}