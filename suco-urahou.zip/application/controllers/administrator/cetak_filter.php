<?php
 Class cetak_filter extends CI_Controller{
     public function index()
     {
         $data['periodo']= $this->db->get('periodo')->result();
         $this->load->view('administrator/filter', $data);

     }
     public function filter($id_periodo)
     {
         if ($id_periodo ==0){
             $data = $this->db->get('t_populasaun')->result();
         }else{
            $data = $this->db->get_where('t_populasaun', ['id_periodo'=>$id_periodo])->result();
         }
        $dt['populasaun'] = $data;
        $dt['id_periodo'] = $id_periodo;
        $this->load->view('administrator/result', $dt);
     }

     public function cetak($id_periodo)
     {
        if ($id_periodo ==0){
            $data = $this->db->get('t_populasaun')->result();
        }else{
           $data = $this->db->get_where('t_populasaun', ['id_periodo'=>$id_periodo])->result();
        }
       $dt['populasaun'] = $data;
       $this->load->library('dompdf_gen');
       
    $this->load->view('administrator/cetak', $dt, 'relatorio-populasaun', 'A4', 'landscape');
       
     }   
     
 }