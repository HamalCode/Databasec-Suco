<?php
Class nestudo extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_nivel_estudu']  =$this->nestudo_model->fosai_dadus('t_nivel_estudu')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_nivel/nestudu',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id'	             =>set_value('id'),
			'id_nivel'	        =>set_value('id_nivel'),
			'nrn_nivel'	      =>set_value('nrn_nivel'),
		);
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_nivel/form_nivel',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'id_nivel'           =>$this->input->post('id_nivel',TRUE),
				'nrn_nivel'   =>$this->input->post('nrn_nivel',TRUE),
			);
			$this->nestudo_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Nivel Estudo Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/nestudo');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('id_nivel','id','required',[
			'required' =>'Favor Prense ID Nivel'
		]);
		$this->form_validation->set_rules('nrn_nivel','nrn_nivel','required',[
			'required' =>'Favor prense naran Nivel'
		]);
	}

    public function update($id)
	{
		$where = array('id' => $id);
		
		$data['t_nivel_estudu']=$this->nestudo_model->edit_data($where,'t_nivel_estudu')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_nivel/update_nestudu',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id = $this->input->post('id');
		$id_nivel   = $this->input->post('id_nivel');
		$nrn_nivel = $this->input->post('nrn_nivel');

		$data = array(
			'id_nivel'      => $id_nivel,
			'nrn_nivel' => $nrn_nivel
		);

		$where = array(
			'id' =>$id
		);
		$this->nestudo_model->update_data($where,$data,'t_nivel_estudu');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus Nivel Estudo Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/nestudo');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->nestudo_model->hamos_data($where, 't_nivel_estudu');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus Nivel Estudo Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/nestudo');
	}
    public function print()
	{
		$data['t_nivel_estudu']= $this->nstudo_model->fosai_dadus('t_nivel_estudu')->result();
        $this->load->view('administrator/print_nstudo',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_nivel_estudu']=$this->nestudo_model->fosai_dadus("t_nivel_estudu")->result();
        $this->load->view('administrator/relnestudo_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_aldeia.pdf", array('attachment'=>0));
     }

}