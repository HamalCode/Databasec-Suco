<?php
Class prosesu_populasaun extends CI_Controller{
    public function index()
	{
		$getData = $this->populasaun_model->get();

        $data = [
            
            'jumlah_data' => $getData->num_rows()
        ];
		
		$data['t_populasaun']  =$this->populasaun_model->fosai_dadus('t_populasaun')->result();
		$data['t_religiaun']  =$this->populasaun_model->fosai_dadus('t_religiaun')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_prosesu/prosesu_populasaun',$data);
		$this->load->view('templates_administrator/footer');
	}

}