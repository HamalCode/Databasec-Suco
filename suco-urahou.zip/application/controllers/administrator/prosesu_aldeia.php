<?php
Class prosesu_aldeia extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_aldeia']  =$this->aldeia_model->fosai_dadus('t_aldeia')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_prosesu/prosesu_aldeia',$data);
		$this->load->view('templates_administrator/footer');
	}

  

}