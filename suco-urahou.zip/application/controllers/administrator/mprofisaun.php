<?php
Class mprofisaun extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_mprofisaun']  =$this->mprofisaun_model->fosai_dadus('t_mprofisaun')->result();
		$data['t_mud_nivelestudo']  =$this->mprofisaun_model->fosai_dadus('t_mud_nivelestudo')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mprofisaun/mprofisaun',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id'	              =>set_value('id'),
			'id_profisaun'	      =>set_value('id_profisaun'),
			'nrn_profisaun'	      =>set_value('nrn_profisaun'),
			'id_nivel'	      =>set_value('id_nivel'),
            'data_muda'	          =>set_value('data_muda'),
		);
		$data['t_mprofisaun']  =$this->mprofisaun_model->fosai_dadus('t_mprofisaun')->result();
		$data['t_mud_nivelestudo']  =$this->mprofisaun_model->fosai_dadus('t_mud_nivelestudo')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mprofisaun/form_mprofisaun',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'id_profisaun'           =>$this->input->post('id_profisaun',TRUE),
				'nrn_profisaun'   =>$this->input->post('nrn_profisaun',TRUE),
				 'id_nivel'           =>$this->input->post('id_nivel',TRUE),
                'data_muda'   =>$this->input->post('data_muda',TRUE),
			);
			$this->mprofisaun_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Mudansa Profisaun Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/mprofisaun');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('id_profisaun','id','required',[
			'required' =>'Favor Prense ID Profisaun'
		]);
		 $this->form_validation->set_rules('id_nivel','id_nivel','required',[
		 	'required' =>'Favor Prense ID Level'
		 ]);
		$this->form_validation->set_rules('nrn_profisaun','nrn_profisaun','required',[
			'required' =>'Favor prense naran Profisaun'
		]);
		$this->form_validation->set_rules('data_muda','data_muda','required',[
			'required' =>'Favor prense data'
		]);
	}

    public function update($id)
	{
		
		$where = array('id' => $id);
		$data['t_mprofisaun']=$this->mprofisaun_model->edit_data($where,'t_mprofisaun')->result();
		$data['t_mud_nivelestudo']  =$this->mprofisaun_model->fosai_dadus('t_mud_nivelestudo')->result();
		

		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mprofisaun/update_mprofisaun',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id = $this->input->post('id');
		$id_profisaun = $this->input->post('id_profisaun');
		$id_level = $this->input->post('id_level');
		$nrn_profisaun   = $this->input->post('nrn_profisaun');
		$data_muda = $this->input->post('data_muda');

		$data = array(
			'id_profisaun'      => $id_profisaun,
			// 'id_level'      => $id_level,
			'nrn_profisaun' => $nrn_profisaun,
			'data_muda' => $data_muda
		);

		$where = array(
			'id' =>$id
		);
		$this->mprofisaun_model->update_data($where,$data,'t_mprofisaun');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus Profisaun Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/mprofisaun');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->mprofisaun_model->hamos_data($where, 't_mprofisaun');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus profisaun Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/mprofisaun');
	}
    public function print()
	{
		$data['t_mprofisaun']= $this->mprofisaun_model->fosai_dadus('t_mprofisaun')->result();
        $this->load->view('administrator/print_aldeia',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_mprofisaun']=$this->mprofisaun_model->fosai_dadus("t_mprofisaun")->result();
        $this->load->view('administrator/relaldeia_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_aldeia.pdf", array('attachment'=>0));
     }

}