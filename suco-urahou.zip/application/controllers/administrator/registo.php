<?php
defined('BASEPATH') or exit('No direct script access allowed');
class registo extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        //load helper
        $this->load->helper('url');
        $this->load->helper('form');
        //load library  
        $this->load->library('form_validation');
        //load model 
        $this->load->model('registo_model');
    }

    public function index()
    {
        //ambil data dari database
       
        $getData = $this->registo_model->get();
      

        $data = [
            'registo' => $getData->result_array(),
            'jumlah_data' => $getData->num_rows()
        ];
        
        //menampilkan view
        $this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/registo', $data);
        $this->load->view('templates_administrator/footer');
    }

     
    
    public function create()
    {
        //rule validasi
        $validation_rules = [
            [
                'field' => 'nrep',
                'label' => 'No. registo',
                'rules' => 'required'
            ],
            [
                'field' => 'naran',
                'label' => 'Naran',
                'rules' => 'required'
            ],
            [
                'field' => 'sexo',
                'label' => ' Sexo',
                'rules' => 'required'
            ],
            [
                'field' => 'status',
                'label' => ' Status',
                'rules' => 'required'
            ],
            [
                'field' => 'fatin_moris',
                'label' => 'Fatin Moris',
                'rules' => 'required'
            ],
            [
                'field' => 'data_moris',
                'label' => 'data_moris',
                'rules' => 'required'
            ],
            [
                'field' => 'no_eleitoral',
                'label' => 'no eleitoral',
                'rules' => 'required'
            ],
            [
                'field' => 'np_fixa',
                'label' => 'no fixa',
                'rules' => 'required'
            ],
             [
                'field' => 'code_aldeia',
                'label' => 'Codigo Aldeia',
                'rules' => 'required'
             ],
             [
                'field' => 'hela_fatin',
                'label' => 'Hela fatin',
                'rules' => 'required'
            ]
        ];

        //set rule validasi
       
        $this->form_validation->set_rules($validation_rules);

        if ($this->form_validation->run() === FALSE) {
            $data['t_aldeia'] = $this->aldeia_model->fosai_dadus('t_aldeia')->result();
            $this->load->view('templates_administrator/header');
	      	$this->load->view('templates_administrator/sidebar');
            $this->load->view('administrator/add');
            $this->load->view('templates_administrator/footer');
        } else {

            //data mahasiswa
            $registo = [
                'nrep' => $this->input->post('nrep'),
                'naran' => $this->input->post('naran'),
                'fatin_moris' => $this->input->post('fatin_moris'),
                'data_moris' => $this->input->post('data_moris'),
                'sexo' => $this->input->post('sexo'),
                'status' => $this->input->post('status'),
                'fatin_moris' => $this->input->post('fatin_moris'),
                'no_eleitoral' => $this->input->post('no_eleitoral'),
                'no_fixa' => $this->input->post('no_fixa'),
                'code_aldeia' => $this->input->post('code_aldeia'),
                'hela_fatin' => $this->input->post('hela_fatin')
            ];
           

            $this->registo_model->insert($registo);
        
            $data['msg']  =  'Data berhasil disimpan';

            $this->load->view('administrator/notifikasi', $data);
        }
    }

    public function edit($nrep = '')
    {
        //Cek apakah ada parameter $nim
        if ('' == $nrep) {
            //jika tidak ada, maka alihkan ke halaman daftar mahasiswa
            redirect('administratot/registo');
        }
        //ambil data mahasisa berdasarkan nim
        $data['registo'] =  $this->registo_model->get_by_nrep($nrep)->row_array();
        //load form edit
        $this->load->view('registo/edit', $data);
    }

    public function update()
    {
        //cek apakah tombol update ditekan
        if ($this->input->post('update')) {
            $nim = $this->input->post('nim');

            //rule validasi
            $validation_rules = [
                [
                    'field' => 'nrep',
                    'label' => 'No. registo',
                    'rules' => 'required'
                ],
                [
                    'field' => 'naran',
                    'label' => 'Naran',
                    'rules' => 'required'
                ],
                [
                    'field' => 'sexo',
                    'label' => ' Sexo',
                    'rules' => 'required'
                ],
                [
                    'field' => 'fatin_moris',
                    'label' => 'Fatin Moris',
                    'rules' => 'required'
                ],
                [
                    'field' => 'data_moris',
                    'label' => 'data_moris',
                    'rules' => 'required'
                ],
                [
                    'field' => 'no_eleitoral',
                    'label' => 'no eleitoral',
                    'rules' => 'required'
                ],
                 [
                    'field' => 'code_aldeia',
                    'label' => 'Codigo Aldeia',
                    'rules' => 'required'
                 ],
                 [
                    'field' => 'hela_fatin',
                    'label' => 'Hela fatin',
                    'rules' => 'required'
                ]
            ];

            //set rule validasi
            $this->form_validation->set_rules($validation_rules);

            if ($this->form_validation->run() === false) {
                redirect('registo/edit/' . $nim);
            }

            $where['nrep'] = $nrep;

            //data mahasiswa
            $registo = [
                'nrep' => $this->input->post('nrep'),
                'naran' => $this->input->post('naran'),
                'fatin_moris' => $this->input->post('fatin_moris'),
                'data_moris' => $this->input->post('data_moris'),
                'sexo' => $this->input->post('sexo'),
                'status' => $this->input->post('status'),
                'fatin_moris' => $this->input->post('fatin_moris'),
                'no_eleitoral' => $this->input->post('no_eleitoral'),
                'no_fixa' => $this->input->post('no_fixa'),
                'code_aldeia' => $this->input->post('code_aldeia'),
                'hela_fatin' => $this->input->post('hela_fatin')
            ];

            //update data
            $this->registo_model->update($registo, $where);

            $data['msg'] = 'Dadus Sucesu Amenta';
            $this->load->view('registo/notifikasi', $data);
        } else {
            echo "<h3 style='color:red;'>Forbidden access</h3>";
        }
    }
    public function hapus($nrep = '')
    {
        //cek apakah parameter nim ada
        if ('' == $nrep) {
            //jika tidak, tampilkan error
            return show_404();
        }
        //hapus data
        $this->registo_model->delete($nrep);

        $data['msg']  =  'Dadus Sucesu Hamos';
        $this->load->view('administrator/notifikasi', $data);
    }

}