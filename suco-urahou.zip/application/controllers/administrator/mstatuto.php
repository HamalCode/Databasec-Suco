<?php
Class mstatuto extends CI_Controller{
    public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_mud_statuto']  =$this->mstatuto_model->fosai_dadus('t_mud_statuto')->result();
		$data['t_populasaun']  =$this->mstatuto_model->fosai_dadus('t_populasaun')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mudstatuto/mstatuto',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function input()
	{
		$data = array(
			'id'	             =>set_value('id'),
			'id_populasaun'	        =>set_value('id_populasaun'),
			'id_mstatuto'	      =>set_value('id_mstatuto'),
			'data_muda'	      =>set_value('data_muda'),
		);
		$data['t_populasaun']  =$this->mstatuto_model->fosai_dadus('t_populasaun')->result();
		$data['t_mud_statuto']  =$this->mstatuto_model->fosai_dadus('t_mud_statuto')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mudstatuto/form_mstatuto',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'id_populasaun'           =>$this->input->post('id_populasaun',TRUE),
				'id_mstatuto'   =>$this->input->post('id_mstatuto',TRUE),
				'data_muda'   =>$this->input->post('data_muda',TRUE),
			);
			$this->mstatuto_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Muda statuto Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/mstatuto');
		}

	}

    public function _rules()
	{
		$this->form_validation->set_rules('id_populasaun','id','required',[
			'required' =>'Favor Prense ID populasaun'
		]);
		$this->form_validation->set_rules('id_mstatuto','id_mstatuto','required',[
			'required' =>'Favor prense Id '
		]);
		$this->form_validation->set_rules('data_muda','data_muda','required',[
			'required' =>'Favor muda data'
		]);
	}

    public function update($id)
	{
		$where = array('id' => $id);
		$data['t_mud_statuto']=$this->mstatuto_model->edit_data($where,'t_mud_statuto')->result();
	
		$data['t_mud_statuto'] = $this->db->query("select * from t_mud_statuto msta, t_populasaun pop where msta.id_populasaun=pop.id_populasaun and pop.id='$id'")->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/mod_mudstatuto/update_mstatuto',$data);
		$this->load->view('templates_administrator/footer');
	}

    public function asaun_update()
	{
		$id = $this->input->post('id');
		$id_populasaun   = $this->input->post('id_populasaun');
		$id_mstatuto = $this->input->post('id_mstatuto');
		$data_muda = $this->input->post('data_muda');

		$data = array(
			'id_populasaun'      => $id_populasaun,
			'id_mstatuto'       => $id_mstatuto,
			'data_muda'       => $data_muda
		);

		$where = array(
			'id' =>$id
		);
		$this->mstatuto_model->update_data($where,$data,'t_mud_statuto');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus Muda statuto Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/mstatuto');

	}

    public function delete($id)
	{
		$where = array('id' => $id);
		$this->mstatuto_model->hamos_data($where, 't_mud_statuto');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show text-white" role="alert">
					Dadus muda statuto Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/mstatuto');
	}
    public function print()
	{
		$data['t_mud_statuto']= $this->mstatuto_model->fosai_dadus('t_mud_statuto')->result();
        $this->load->view('administrator/mod_mudstatuto/print_estatuto',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_mud_statuto']=$this->mstatuto_model->fosai_dadus("t_mud_statuto")->result();
        $this->load->view('administrator/relamstatuto_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("relatorio_mstatuto.pdf", array('attachment'=>0));
     }

}