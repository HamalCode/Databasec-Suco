-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2021 at 05:52 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `suku_urahou`
--

-- --------------------------------------------------------

--
-- Table structure for table `periodo`
--

CREATE TABLE `periodo` (
  `id_periodo` int(11) NOT NULL,
  `tinan` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `periodo`
--

INSERT INTO `periodo` (`id_periodo`, `tinan`) VALUES
(1, '2019'),
(2, '2020'),
(3, '2021'),
(4, '2022'),
(5, '2024');

-- --------------------------------------------------------

--
-- Table structure for table `t_aldeia`
--

CREATE TABLE `t_aldeia` (
  `id` int(11) NOT NULL,
  `code_aldeia` int(4) NOT NULL,
  `nrn_aldeia` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_aldeia`
--

INSERT INTO `t_aldeia` (`id`, `code_aldeia`, `nrn_aldeia`) VALUES
(1, 1, 'Manuhatu'),
(2, 2, 'Dosmagar'),
(3, 3, 'Laulema'),
(4, 4, 'Hatu-lailete'),
(5, 5, 'Kaitarlo'),
(6, 6, 'Raimean');

-- --------------------------------------------------------

--
-- Table structure for table `t_estatuto`
--

CREATE TABLE `t_estatuto` (
  `id` int(11) NOT NULL,
  `id_populasaun` int(4) NOT NULL,
  `id_estatuto` char(12) NOT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_estatuto`
--

INSERT INTO `t_estatuto` (`id`, `id_populasaun`, `id_estatuto`, `data`) VALUES
(1, 1, '1', '2021-09-07');

-- --------------------------------------------------------

--
-- Table structure for table `t_fixa_familia`
--

CREATE TABLE `t_fixa_familia` (
  `id` int(11) NOT NULL,
  `id_fixa` int(8) NOT NULL,
  `id_populasaun` varchar(50) NOT NULL,
  `data_moris` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_fixa_familia`
--

INSERT INTO `t_fixa_familia` (`id`, `id_fixa`, `id_populasaun`, `data_moris`) VALUES
(8, 7839, '1', '2021-09-13'),
(9, 9370, '52401', '2021-09-08'),
(10, 7839, '3', '2021-09-01'),
(11, 1223, '3', '2021-09-21'),
(12, 120, '8', '2016-11-01');

-- --------------------------------------------------------

--
-- Table structure for table `t_mprofisaun`
--

CREATE TABLE `t_mprofisaun` (
  `id` int(11) NOT NULL,
  `id_profisaun` int(4) NOT NULL,
  `nrn_profisaun` varchar(50) NOT NULL,
  `id_nivel` int(4) NOT NULL,
  `data_muda` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_mprofisaun`
--

INSERT INTO `t_mprofisaun` (`id`, `id_profisaun`, `nrn_profisaun`, `id_nivel`, `data_muda`) VALUES
(5, 2, 'FDTL', 1, '2021-09-14'),
(6, 398, 'Securansa Civil', 2, '2021-09-08'),
(7, 3989, 'FDTL', 2, '2021-09-14');

-- --------------------------------------------------------

--
-- Table structure for table `t_mud_nivelestudo`
--

CREATE TABLE `t_mud_nivelestudo` (
  `id` int(11) NOT NULL,
  `id_populasaun` int(10) NOT NULL,
  `id_nivel` char(10) NOT NULL,
  `data_muda` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_mud_nivelestudo`
--

INSERT INTO `t_mud_nivelestudo` (`id`, `id_populasaun`, `id_nivel`, `data_muda`) VALUES
(1, 1, '1', '2021-09-13'),
(2, 2, '2', '2021-09-20');

-- --------------------------------------------------------

--
-- Table structure for table `t_mud_statuto`
--

CREATE TABLE `t_mud_statuto` (
  `id` int(11) NOT NULL,
  `id_populasaun` int(10) NOT NULL,
  `id_mstatuto` char(10) NOT NULL,
  `data_muda` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_mud_statuto`
--

INSERT INTO `t_mud_statuto` (`id`, `id_populasaun`, `id_mstatuto`, `data_muda`) VALUES
(4, 1, '2', '2021-09-15'),
(5, 2, '4', '2021-09-14');

-- --------------------------------------------------------

--
-- Table structure for table `t_nivel_estudu`
--

CREATE TABLE `t_nivel_estudu` (
  `id` int(11) NOT NULL,
  `id_nivel` int(10) NOT NULL,
  `nrn_nivel` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_nivel_estudu`
--

INSERT INTO `t_nivel_estudu` (`id`, `id_nivel`, `nrn_nivel`) VALUES
(1, 1, 'S3'),
(4, 2, 'S2'),
(5, 3, 'D1'),
(6, 4, 'S3');

-- --------------------------------------------------------

--
-- Table structure for table `t_populasaun`
--

CREATE TABLE `t_populasaun` (
  `id` int(11) NOT NULL,
  `id_populasaun` char(5) NOT NULL,
  `nrn_kompletu` varchar(50) NOT NULL,
  `f_moris` varchar(100) NOT NULL,
  `d_moris` char(50) NOT NULL,
  `sexo` char(8) NOT NULL,
  `code_reli` char(10) NOT NULL,
  `obs` text,
  `id_periodo` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_populasaun`
--

INSERT INTO `t_populasaun` (`id`, `id_populasaun`, `nrn_kompletu`, `f_moris`, `d_moris`, `sexo`, `code_reli`, `obs`, `id_periodo`) VALUES
(10, '1', 'Marcos Boavida', 'Ermera', '2021-09-14', 'Mane', '1', 'Diak', '1'),
(11, '2', 'Mario', 'Ermera', '2021-09-07', 'Mane', '2', 'Diak', '2'),
(21, '3', 'Antonio Albano', 'Ermera', '2021-09-15', 'Mane', '2', 'Diak', '3'),
(22, '4', 'Francelina', 'Hatulia', '2021-09-08', 'Feto', '2', 'Diak', '1'),
(23, '5', 'Angela Maia', 'Ermera', '2021-09-29', 'Feto', '1', 'Diak', '3'),
(24, '6', 'Jon', 'Hatulia', '2021-09-07', 'Mane', '2', 'Diak', '2'),
(25, '7', 'Mario', 'Hatulia', '2021-09-15', 'Mane', '2', 'Diak', '2');

-- --------------------------------------------------------

--
-- Table structure for table `t_profisaun`
--

CREATE TABLE `t_profisaun` (
  `id` int(11) NOT NULL,
  `id_profisaun` int(10) NOT NULL,
  `id_nivel` char(2) NOT NULL,
  `nrn_profisaun` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_registo`
--

CREATE TABLE `t_registo` (
  `id` int(11) NOT NULL,
  `nrep` char(20) NOT NULL,
  `naran` char(100) NOT NULL,
  `sexo` enum('Mane','Feto') NOT NULL,
  `status` char(12) NOT NULL,
  `data_moris` date NOT NULL,
  `fatin_moris` char(50) NOT NULL,
  `no_eleitoral` char(12) NOT NULL,
  `no_fixa` char(6) NOT NULL,
  `code_aldeia` char(20) NOT NULL,
  `hela_fatin` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_registo`
--

INSERT INTO `t_registo` (`id`, `nrep`, `naran`, `sexo`, `status`, `data_moris`, `fatin_moris`, `no_eleitoral`, `no_fixa`, `code_aldeia`, `hela_fatin`) VALUES
(7, '77878', 'Mario Joseferino', 'Mane', 'Klosan', '2021-08-25', 'dili', '98765', '2345', '231', 'Bidau');

-- --------------------------------------------------------

--
-- Table structure for table `t_religiaun`
--

CREATE TABLE `t_religiaun` (
  `id` int(11) NOT NULL,
  `code_reli` char(4) NOT NULL,
  `nrn_reli` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_religiaun`
--

INSERT INTO `t_religiaun` (`id`, `code_reli`, `nrn_reli`) VALUES
(1, '1', 'Catolik'),
(2, '2', 'Islam'),
(3, '3', 'Protestante'),
(4, '4', 'Hindu');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(40) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  `blokir` enum('Y','N') NOT NULL,
  `id_session` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `level`, `blokir`, `id_session`) VALUES
(12, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'namessapinto@gmail.com', 'admin', 'N', 'd41d8cd98f00b204e9800998ecf8427e'),
(18, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'itsilvinoalbano@gmail.com', 'admin', 'N', 'd41d8cd98f00b204e9800998ecf8427e'),
(20, 'albano', 'albano', 'itsilvinoalbano@gmail.com', 'admin', 'N', 'd41d8cd98f00b204e9800998ecf8427e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `periodo`
--
ALTER TABLE `periodo`
  ADD PRIMARY KEY (`id_periodo`);

--
-- Indexes for table `t_aldeia`
--
ALTER TABLE `t_aldeia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_estatuto`
--
ALTER TABLE `t_estatuto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_fixa_familia`
--
ALTER TABLE `t_fixa_familia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_mprofisaun`
--
ALTER TABLE `t_mprofisaun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_mud_nivelestudo`
--
ALTER TABLE `t_mud_nivelestudo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_mud_statuto`
--
ALTER TABLE `t_mud_statuto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_nivel_estudu`
--
ALTER TABLE `t_nivel_estudu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_populasaun`
--
ALTER TABLE `t_populasaun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_profisaun`
--
ALTER TABLE `t_profisaun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_registo`
--
ALTER TABLE `t_registo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_religiaun`
--
ALTER TABLE `t_religiaun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `periodo`
--
ALTER TABLE `periodo`
  MODIFY `id_periodo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `t_aldeia`
--
ALTER TABLE `t_aldeia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `t_estatuto`
--
ALTER TABLE `t_estatuto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `t_fixa_familia`
--
ALTER TABLE `t_fixa_familia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `t_mprofisaun`
--
ALTER TABLE `t_mprofisaun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `t_mud_nivelestudo`
--
ALTER TABLE `t_mud_nivelestudo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `t_mud_statuto`
--
ALTER TABLE `t_mud_statuto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `t_nivel_estudu`
--
ALTER TABLE `t_nivel_estudu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `t_populasaun`
--
ALTER TABLE `t_populasaun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `t_profisaun`
--
ALTER TABLE `t_profisaun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `t_registo`
--
ALTER TABLE `t_registo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `t_religiaun`
--
ALTER TABLE `t_religiaun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
